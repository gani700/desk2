/*
 * Copyright (C) 2015    Raphaël Beamonte <raphael.beamonte@polymtl.ca>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation  and/or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of any
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * This file has been created for the purpose of the INF1010
 * course of École Polytechnique de Montréal.
 */

#include "maincli.h"
#include "maingui.h"
#include "Employee.h"
#include "Secretary.h"
#include "Manager.h"

#include <string>

#include <QApplication>

/**
 * @brief help shows and help message on the available command line arguments
 */
void help() {
    cout << "Command line arguments:" << endl;
    cout << "   -c, --cli   Shows the command line interface" << endl;
    cout << "   -g, --gui   Shows the graphical user interface" << endl;
    cout << "   -h, --help  Shows this message" << endl;
}

/**
 * @brief main Main function of the program
 * @param argc Number of arguments received on the command line
 * @param argv Values of the arguments received on the command line
 * @return 0 if everything went fine, the error code else
 */
int main(int argc, char *argv[])
{
    // Manage command line arguments
    bool use_gui = true;

    for (int i = 1; i < argc; i++) {
        string opt(argv[i]);
        if (opt == "-c" || opt == "--cli") {
            use_gui = false;
        } else if (opt == "-g" || opt == "--gui") {
            use_gui = true;
        } else if (opt == "-h" || opt == "--help") {
            help();
            return 0;
        } else {
            cout << "Unknown parameter " << opt << endl;
            help();
            abort();
        }
    }


    // Create a company
    Company poly("Polytechnique", "Michele");

    // Add some employees
    Employee e1("John", 15000);
    Secretary e2("Mark", 16000);
    Manager e3("Jenny", 12000);

    poly.addEmployee(&e1);
    poly.addEmployee(&e2);
    poly.addEmployee(&e3);

    if (use_gui) {
        // Start the GUI
        QApplication a(argc, argv);
        MainGui gui(&poly);
        gui.show();

        return a.exec();

    } else {
        // Start the CLI
        MainCli cli(&poly);
        cli.run();

        return 0;
    }
}
