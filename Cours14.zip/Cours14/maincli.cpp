/*
 * Copyright (C) 2015    Raphaël Beamonte <raphael.beamonte@polymtl.ca>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation  and/or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of any
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * This file has been created for the purpose of the INF1010
 * course of École Polytechnique de Montréal.
 */

#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <typeinfo>
using namespace std;

#include "maincli.h"
#include "Manager.h"
#include "Secretary.h"
#include "Employee.h"

string trim(string& str)
{
    size_t first = str.find_first_not_of(' ');
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last-first+1));
}

MainCli::MainCli(Company *company)
    : company_(company)
{
}

void MainCli::run() {
    cout << "Welcome to the command line interface." << endl;
    cout << "You're currently managing the employees of " << company_->getName() << endl;
    cout << "If you don't know where to start, please use 'help'." << endl;

    istringstream* iss;
    string line;
    bool proceed = true;
    while (proceed) {
        cout << company_->getName() << "> ";
        getline(cin, line);

        if (!line.empty()) {
            if (line == "exit") {
                proceed = false;
            } else {
                iss = new istringstream(line);

                process(iss);

                delete iss;
                iss = 0;
            }
        }
    }

    cout << "Goodbye.\n";
}

MainCli::~MainCli() {
    while (!added_.empty()) {
        delete added_.back();
        added_.pop_back();
    }
}

void MainCli::getword(istream* iss, string& word) {
    if (iss == 0) {
        word = "";
    } else {
        *iss >> word;
    }
}

void MainCli::process(istringstream* iss) {
    string word;
    getword(iss, word);

    if (word == "fire") {
        command_fire(iss);
    } else if (word == "hire") {
        command_hire(iss);
    } else if (word == "list") {
        command_list(iss);
    } else if (word == "help") {
            command_help(iss);
    } else {
        command_help(0);
    }
}

void MainCli::command_help(istringstream* iss) {
    string word;
    getword(iss, word);

    if (word == "fire") {
            cout << "Fire someone or everybody." << endl;
            cout << "Syntax: fire {name|all}" << endl;
            cout << "   {name|all} - Name of the employee, or 'all' to fire everyone" << endl;

    } else if (word == "hire") {
        cout << "Hire someone." << endl;
        cout << "Syntax: hire {m|s|e} {name} {salary} [bonus]" << endl;
        cout << "   {m|s|e}  - Type (Manager, Secretary or Employee)" << endl;
        cout << "   {name}   - Name of the employee" << endl;
        cout << "   {salary} - Base salary" << endl;
        cout << "   [bonus]  - Bonus (only for managers)" << endl;

    } else if (word == "list") {
        cout << "List the employees." << endl;
        cout << "Syntax: list [m|s|e]" << endl;
        cout << "   [m|s|e] - To list only the Managers, Secretaries or Employees" << endl;

    } else {
        cout << "Commands available:" << endl;
        cout << "   fire {name|all}" << endl;
        cout << "   hire {m|s|e} {name} {salary} [bonus]" << endl;
        cout << "   list [m|s|e]" << endl;

    }
}

void MainCli::command_fire(istringstream* iss) {
    string fire;
    getline(*iss, fire);
    fire = trim(fire);

    if (fire == "all") {
        if (company_->hasEmployees()) {
            do {
                Employee* e = company_->getEmployee(0);
                company_->delEmployee(e);
                cout << "Employee '" << e->getName() << "' fired." << endl;

                deleteIfLocal(e);
            } while (company_->hasEmployees());
        } else {
            cout << "Noone to fire." << endl;
        }
    } else {
        Employee* e = company_->getEmployee(fire);
        if (e == 0) {
            cout << "Employee '" << fire << "' not found." << endl;
        } else {
            company_->delEmployee(e);
            cout << "Employee '" << e->getName() << "' fired." << endl;

            deleteIfLocal(e);
        }
    }
}

void MainCli::deleteIfLocal(Employee* e) {
    // STL
    vector<Employee*>::iterator it = find (added_.begin(), added_.end(), e);
    if (it != added_.end()) {
        added_.erase(it);
    }
}

void MainCli::command_hire(istringstream* iss) {
    string type;
    getword(iss, type);

    // STL
    transform(type.begin(), type.end(), type.begin(), ::tolower);

    Employee* newEmployee;

    string name, salary, bonus;
    *iss >> name >> salary >> bonus;

    if (type == "m") {
        newEmployee = new Manager(name, stod(salary), stod(bonus));
        cout << "Hired manager '" << name << "' with a salary of " << salary << " and a bonus of " << bonus << endl;
    } else if (type == "s") {
        newEmployee = new Secretary(name, stod(salary));
        cout << "Hired secretary '" << name << "' with a salary of " << salary << endl;
    } else if (type == "e") {
        newEmployee = new Employee(name, stod(salary));
        cout << "Hired employee '" << name << "' with a salary of " << salary << endl;
    } else {
        cout << "Error." << endl;
        return;
    }

    company_->addEmployee(newEmployee);
    added_.push_back(newEmployee);
}

void MainCli::command_list(istringstream* iss) {
    string type;
    getword(iss, type);

    // STL
    transform(type.begin(), type.end(), type.begin(), ::tolower);

    bool printM = false, printS = false, printE = false;

    if (type == "m") {
        printM = true;
    } else if (type == "s") {
        printS = true;
    } else if (type == "e") {
        printE = true;
    } else if (type == "") {
        printM = true;
        printS = true;
        printE = true;
    } else {
        cout << "Error." << endl;
        return;
    }

    int nb = company_->getNumberEmployees();
    for (int i = 0; i < nb; i++) {
        Employee* e = company_->getEmployee(i);

        if ((printM && typeid(*e) == typeid(Manager))
            || (printS && typeid(*e) == typeid(Secretary))
            || (printE && typeid(*e) == typeid(Employee)))
        {
            cout << e->getName() << endl;
        }
    }
}
