/*
 * Copyright (C) 2015    Raphaël Beamonte <raphael.beamonte@polymtl.ca>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation  and/or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of any
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * This file has been created for the purpose of the INF1010
 * course of École Polytechnique de Montréal.
 */

#ifndef MAINCLI_H
#define MAINCLI_H

#include <iostream>
#include <memory>
#include <sstream>
#include <vector>

#include "Company.h"
using namespace std;

/**
 * @brief The MainCli class allowing to enable a command line interface
 */
class MainCli
{
public:
    /**
     * @brief MainCli The constructor receiving a company on which it will work
     */
    MainCli(Company*);
    /**
     * @brief ~MainCli The destructor
     */
    ~MainCli();
    /**
     * @brief run To start running the command line interface
     */
    void run();
private:
    /**
     * @brief getword To get the next word from a stream
     * @param is The stream from which to read
     * @param word The string in which to store the next word
     */
    void getword(istream*, string&);
    /**
     * @brief process To process a received command
     * @param iss The istringstream in which is stored the command
     */
    void process(istringstream*);
    /**
     * @brief command_help To process a received command starting by 'help'
     * @param iss The istringstream in which is stored the command
     */
    void command_help(istringstream*);
    /**
     * @brief command_fire To process a received command starting by 'fire'
     * @param iss The istringstream in which is stored the command
     */
    void command_fire(istringstream*);
    /**
     * @brief command_hire To process a received command starting by 'hire'
     * @param iss The istringstream in which is stored the command
     */
    void command_hire(istringstream*);
    /**
     * @brief command_list To process a received command starting by 'list'
     * @param iss The istringstream in which is stored the command
     */
    void command_list(istringstream*);

    /**
     * @brief deleteIfLocal To delete an employee pointer if it has been created locally
     * @param employee The employee to delete if it has been created locally
     */
    void deleteIfLocal(Employee*);

    /**
     * @brief company_ To store the company on which this CLI works
     */
    Company* company_;
    /**
     * @brief added_ To store the locally created employees for later deletion
     */
    vector<Employee*> added_;
};

#endif // MAINCLI_H
