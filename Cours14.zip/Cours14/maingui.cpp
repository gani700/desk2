/*
 * Copyright (C) 2015    Raphaël Beamonte <raphael.beamonte@polymtl.ca>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation  and/or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of any
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * This file has been created for the purpose of the INF1010
 * course of École Polytechnique de Montréal.
 */

#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QStyle>
#include <QKeySequence>

#include <QDebug>

#include <QPushButton>
#include <QRadioButton>
#include <QButtonGroup>
#include <QComboBox>
#include <QSlider>
#include <QListWidget>
#include <QListWidgetItem>
#include <QLineEdit>
#include <QLabel>
#include <QFrame>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include <typeinfo>
#include <string>
using namespace std;

#include "maingui.h"

#include "Company.h"
#include "Employee.h"
#include "Secretary.h"
#include "Manager.h"

Q_DECLARE_METATYPE(Employee*)

MainGui::MainGui(QWidget *parent) :
    QMainWindow(parent)
{
    company_ = new Company();
    companyIsLocal_ = true;
    setup();
}

MainGui::MainGui(Company* company, QWidget *parent) :
    QMainWindow(parent)
{
    company_ = company;
    companyIsLocal_ = false;
    setup();
}

MainGui::~MainGui() {
    if (companyIsLocal_) {
        delete company_;
    }
    while (!added_.empty()) {
        delete added_.back();
        added_.pop_back();
    }
}

void MainGui::setup() {
    currentFilterIndex_ = 0;

    // On créé notre menu et notre UI
    setMenu();
    setUI();

    // On connecte les signaux de notre company aux
    // slots créés localement pour agir suite à ces signaux
    connect(company_, SIGNAL(employeeAdded(Employee*)),
            this, SLOT(employeeHasBeenAdded(Employee*)));
    connect(company_, SIGNAL(employeeDeleted(Employee*)),
            this, SLOT(employeeHasBeenDeleted(Employee*)));

    // On charge la liste des employés actuels
    loadEmployees();
}

void MainGui::setMenu() {
    // On crée un bouton 'Exit'
    QAction* exit = new QAction(tr("E&xit"), this);
    // On ajoute un raccourci clavier qui simulera l'appui sur ce bouton (Ctrl+Q)
    exit->setShortcuts(QKeySequence::Quit);
    // On connecte le clic sur ce bouton avec l'action de clore le programme
    connect(exit, SIGNAL(triggered()), this, SLOT(close()));

    // On crée un nouveau menu 'File'
    QMenu* fileMenu = menuBar()->addMenu(tr("&File"));
    // Dans lequel on ajoute notre bouton 'Exit'
    fileMenu->addAction(exit);
}

void MainGui::setUI() {
    // Le sélecteur pour filtrer ce que l'on souhaite dans la liste
    QComboBox* showCombobox = new QComboBox(this);
    showCombobox->addItem("Show all");                  // Index 0
    showCombobox->addItem("Show only managers");        // Index 1
    showCombobox->addItem("Show only secretaries");     // Index 2
    showCombobox->addItem("Show only other employees"); // Index 3
    connect(showCombobox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(filterList(int)));

    // La liste des employés
    employeesList = new QListWidget(this);
    employeesList->setSortingEnabled(true);
    connect(employeesList, SIGNAL(itemClicked(QListWidgetItem*)),
            this, SLOT(selectEmployee(QListWidgetItem*)));

    // Le bouton pour congédier tout le monde
    QPushButton* fireEveryoneButton = new QPushButton(this);
    fireEveryoneButton->setText("Fire everyone");
    connect(fireEveryoneButton, SIGNAL(clicked()), this, SLOT(fireEveryone()));

    // Le bouton pour remettre à zéro la vue et créer un nouvel employé
    QPushButton* hireSomeoneButton = new QPushButton(this);
    hireSomeoneButton->setText("Hire someone new");
    connect(hireSomeoneButton, SIGNAL(clicked()), this, SLOT(cleanDisplay()));

    // Le premier layout, pour la colonne de gauche, dans lequel on insère les
    // éléments que l'on veut dans l'ordre dans lequel on veut qu'ils apparaissent
    QVBoxLayout* listLayout = new QVBoxLayout;
    listLayout->addWidget(showCombobox);
    listLayout->addWidget(employeesList);
    listLayout->addWidget(fireEveryoneButton);
    listLayout->addWidget(hireSomeoneButton);

    // Champ pour le nom
    QLabel* nameLabel = new QLabel;
    nameLabel->setText("Name:");
    nameEditor = new QLineEdit;

    QHBoxLayout* nameLayout = new QHBoxLayout;
    nameLayout->addWidget(nameLabel);
    nameLayout->addWidget(nameEditor);

    // Champ pour le salaire
    QLabel* salaryLabel = new QLabel;
    salaryLabel->setText("Salary:");
    salaryEditor = new QLineEdit;

    QHBoxLayout* salaryLayout = new QHBoxLayout;
    salaryLayout->addWidget(salaryLabel);
    salaryLayout->addWidget(salaryEditor);

    // Champ pour le bonus
    QLabel* bonusLabel = new QLabel;
    bonusLabel->setText("Bonus:");
    bonusEditor = new QLineEdit;
    bonusEditor->setDisabled(true);

    QHBoxLayout* bonusLayout = new QHBoxLayout;
    bonusLayout->addWidget(bonusLabel);
    bonusLayout->addWidget(bonusEditor);

    // Boutons radio
    QRadioButton* managerRButton = new QRadioButton("&Manager", this);
    employeeTypeRadioButtons.push_back(managerRButton);

    QRadioButton* secretaryRButton = new QRadioButton("&Secretary", this);
    employeeTypeRadioButtons.push_back(secretaryRButton);

    QRadioButton* employeeRButton = new QRadioButton("&Employee", this);
    employeeRButton->setChecked(true);
    employeeTypeRadioButtons.push_back(employeeRButton);

    QButtonGroup* employeeTypeButtonGroup = new QButtonGroup;
    employeeTypeButtonGroup->addButton(managerRButton);
    employeeTypeButtonGroup->addButton(secretaryRButton);
    employeeTypeButtonGroup->addButton(employeeRButton);
    connect(employeeTypeButtonGroup, SIGNAL(buttonClicked(int)),
            this, SLOT(changedType(int)));

    QHBoxLayout* employeeTypeLayout = new QHBoxLayout;
    employeeTypeLayout->addWidget(managerRButton);
    employeeTypeLayout->addWidget(secretaryRButton);
    employeeTypeLayout->addWidget(employeeRButton);

    // Trait horizontal de séparation
    QFrame* horizontalFrameLine = new QFrame;
    horizontalFrameLine->setFrameShape(QFrame::HLine);

    // Bouton pour congédier la ou les personne(s)
    // sélectionnée(s) dans la liste
    fireButton = new QPushButton(this);
    fireButton->setText("Fire");
    fireButton->setDisabled(true);
    connect(fireButton, SIGNAL(clicked()),
            this, SLOT(fireSelected()));

    // Bouton pour embaucher la personne dont on
    // vient d'entrer les informations
    hireButton = new QPushButton(this);
    hireButton->setText("Hire");
    connect(hireButton, SIGNAL(clicked()),
            this, SLOT(createEmployee()));

    // Organisation horizontale des boutons
    QHBoxLayout* fireHireLayout = new QHBoxLayout;
    fireHireLayout->addWidget(fireButton);
    fireHireLayout->addWidget(hireButton);

    // Organisation pour la colonne de droite
    QVBoxLayout* displayLayout = new QVBoxLayout;
    displayLayout->addLayout(nameLayout);
    displayLayout->addLayout(salaryLayout);
    displayLayout->addLayout(bonusLayout);
    displayLayout->addLayout(employeeTypeLayout);
    displayLayout->addWidget(horizontalFrameLine);
    displayLayout->addLayout(fireHireLayout);

    // Trait vertical de séparation
    QFrame* verticalFrameLine = new QFrame;
    verticalFrameLine->setFrameShape(QFrame::VLine);

    // Organisation horizontale
    QHBoxLayout* mainLayout = new QHBoxLayout;
    mainLayout->addLayout(listLayout);
    mainLayout->addWidget(verticalFrameLine);
    mainLayout->addLayout(displayLayout);

    // On crée un nouveau Widget, et on définit son
    // layout pour celui que l'on vient de créer
    QWidget* widget = new QWidget;
    widget->setLayout(mainLayout);

    // Puis on définit ce widget comme le widget
    // centrale de notre classe
    setCentralWidget(widget);

    // Enfin, on met à jour le titre de la fenêtre
    string title = "Employee manager for the company " + company_->getName();
    setWindowTitle(title.c_str());
}

void MainGui::loadEmployees() {
    // On s'assure que la liste est vide
    employeesList->clear();
    // Puis, pour tous les employés dans Company
    int max = company_->getNumberEmployees();
    for (int i = 0; i < max; i++) {
        // On récupère le pointeur vers l'employé
        Employee* employee = company_->getEmployee(i);
        if (employee == nullptr) {
            continue;
        }
        // Et on l'ajoute en tant qu'item de la liste:
        // le nom sera affiché, et le pointeur sera contenu
        QListWidgetItem* item = new QListWidgetItem(
            QString::fromStdString(employee->getName()), employeesList);
        item->setData(Qt::UserRole, QVariant::fromValue<Employee*>(employee));
        item->setHidden(filterHide(employee));
    }
}

bool MainGui::filterHide(Employee* employee) {
    switch (currentFilterIndex_) {
    case 1:
        return (typeid(*employee) != typeid(Manager));
    case 2:
        return (typeid(*employee) != typeid(Secretary));
    case 3:
        return (typeid(*employee) != typeid(Employee));
    case 0:
    default:
        return false;
    }
}

void MainGui::filterList(int index) {
    currentFilterIndex_ = index;

    for (int i = 0; i < employeesList->count(); ++i) {
        QListWidgetItem *item = employeesList->item(i);
        Employee* employee = item->data(Qt::UserRole).value<Employee*>();
        item->setHidden(filterHide(employee));
    }
}

void MainGui::selectEmployee(QListWidgetItem* item) {
    Employee* employee = item->data(Qt::UserRole).value<Employee*>();

    nameEditor->setDisabled(true);
    nameEditor->setText(QString::fromStdString(employee->getName()));

    salaryEditor->setDisabled(true);
    salaryEditor->setText(QString::number(employee->getSalary()));

    bonusEditor->setDisabled(true);
    if (typeid(*employee) == typeid(Manager)) {
        bonusEditor->setText(QString("%1\% (included in salary)").arg(((Manager*)employee)->getBonus()));
    } else {
        bonusEditor->setText("");
    }

    list<QRadioButton*>::iterator end = employeeTypeRadioButtons.end();
    for (list<QRadioButton*>::iterator it = employeeTypeRadioButtons.begin(); it != end; it++) {
        (*it)->setDisabled(true);

        bool checked = false;

        if ((typeid(*employee) == typeid(Manager) && (*it)->text().endsWith("Manager"))
             || (typeid(*employee) == typeid(Secretary) && (*it)->text().endsWith("Secretary"))
             || (typeid(*employee) == typeid(Employee) && (*it)->text().endsWith("Employee"))) {
                checked = true;
        }

        (*it)->setChecked(checked);
    }

    fireButton->setDisabled(false);
    hireButton->setDisabled(true);
}

void MainGui::cleanDisplay() {
    nameEditor->setDisabled(false);
    nameEditor->setText("");

    salaryEditor->setDisabled(false);
    salaryEditor->setText("");

    bonusEditor->setDisabled(true);
    bonusEditor->setText("");

    list<QRadioButton*>::iterator end = employeeTypeRadioButtons.end();
    for (list<QRadioButton*>::iterator it = employeeTypeRadioButtons.begin(); it != end; it++) {
        (*it)->setDisabled(false);
        if ((*it)->text().endsWith("Employee")) {
            (*it)->setChecked(true);
        }
    }

    employeesList->clearSelection();

    fireButton->setDisabled(true);
    hireButton->setDisabled(false);

    nameEditor->setFocus();
}

void MainGui::changedType(int index) {
    if (index == -2) {
        bonusEditor->setDisabled(false);
    } else {
        bonusEditor->setDisabled(true);
    }
}

void MainGui::fireEveryone() {
    vector<Employee*> toDelete;
    for (int i = 0; i < employeesList->count(); ++i) {
        QListWidgetItem *item = employeesList->item(i);
        toDelete.push_back(item->data(Qt::UserRole).value<Employee*>());
    }

    for (Employee* e : toDelete) {
        company_->delEmployee(e);
    }
}

void MainGui::fireSelected() {
    vector<Employee*> toDelete;
    for (QListWidgetItem *item : employeesList->selectedItems()) {
        toDelete.push_back(item->data(Qt::UserRole).value<Employee*>());
    }

    for (Employee* e : toDelete) {
        company_->delEmployee(e);
    }
}

void MainGui::createEmployee() {
    // On va créer un nouvel employé que l'on placera dans ce pointeur
    Employee* newEmployee;

    // On créé le bon type d'employé selon le cas
    QRadioButton* selectedType = 0;
    list<QRadioButton*>::iterator end = employeeTypeRadioButtons.end();
    for (auto it = employeeTypeRadioButtons.begin(); it != end; it++) {
        if ((*it)->isChecked()) {
            selectedType = *it;
            break;
        }
    }

    // On créé le bon type d'employé selon le cas
    if (selectedType->text().endsWith("Manager")) {
        newEmployee = new Manager(nameEditor->text().toStdString(),
                                  salaryEditor->text().toDouble(),
                                  bonusEditor->text().toDouble());
    } else if (selectedType->text().endsWith("Secretary")) {
        newEmployee = new Secretary(nameEditor->text().toStdString(),
                                    salaryEditor->text().toDouble());
    } else {
        newEmployee = new Employee(nameEditor->text().toStdString(),
                                   salaryEditor->text().toDouble());
    }

    // On ajoute le nouvel employé créé à la company
    company_->addEmployee(newEmployee);
    // Mais on le stocke aussi localement pour pouvoir le supprimer plus tard
    added_.push_back(newEmployee);
}

void MainGui::employeeHasBeenAdded(Employee* employee) {
    // On ajoute le nouvel employé comme item de la QListWidget
    QListWidgetItem* item = new QListWidgetItem(
        QString::fromStdString(employee->getName()), employeesList);
    item->setData(Qt::UserRole, QVariant::fromValue<Employee*>(employee));

    // On change la visibilité de notre nouvel employé selon
    // le filtre actuel
    item->setHidden(filterHide(employee));
}

void MainGui::employeeHasBeenDeleted(Employee* e) {
    // On cherche dans notre QlistWidget l'employé pour lequel le
    // signal a été envoyé, afin de l'en retirer
    for (int i = 0; i < employeesList->count(); ++i) {
        QListWidgetItem *item = employeesList->item(i);
        Employee* employee = item->data(Qt::UserRole).value<Employee*>();
        if (employee == e) {
            // delete sur un QlistWidget item va automatiquement le retirer de la liste
            delete item;
            // Si l'employé faisait partie de ceux créés localement, on veut le supprimer.
            auto it = std::find(added_.begin(), added_.end(), e);
            if (it != added_.end()) {
                delete *it;
                added_.erase(it);
            }
            // L'employé ne devrait être qu'une fois dans la liste...
            break;
        }
    }
    // On remet à zéro l'affichage de la colonne de gauche étant
    // donné que les employés sélectionnés ont été supprimés
    cleanDisplay();
}
