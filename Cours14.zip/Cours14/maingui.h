/*
 * Copyright (C) 2015    Raphaël Beamonte <raphael.beamonte@polymtl.ca>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation  and/or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of any
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * This file has been created for the purpose of the INF1010
 * course of École Polytechnique de Montréal.
 */

#ifndef MAINGUI_H
#define MAINGUI_H

#include <QMainWindow>
#include <QListWidget>
#include <QLineEdit>
#include <QRadioButton>
#include <QPushButton>

#include <list>

#include "Company.h"

namespace Ui {
    class MainGui;
}

/**
 * @brief The MainGui class to create a Graphical User Interface using Qt
 */
class MainGui : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief MainGui The constructor receiving no parameters or the parent widget
     * @param parent The parent widget
     */
    explicit MainGui(QWidget *parent = 0);
    /**
     * @brief MainGui The constructor receiving a pointer to a company and, if available, the parent widget
     * @param company The company pointer
     * @param parent The parent widget
     */
    explicit MainGui(Company* company, QWidget *parent = 0);
    /**
     * @brief ~MainGui The destructor
     */
    ~MainGui();

public slots:
    /**
     * @brief filterList Slot to filter the list according to the received parameter
     */
    void filterList(int);
    /**
     * @brief selectEmployee Slot to select an employee given a QListWidgetItem
     */
    void selectEmployee(QListWidgetItem*);
    /**
     * @brief cleanDisplay To clean the editor on the right of the GUI
     */
    void cleanDisplay();
    /**
     * @brief changedType To update the editor when we select a different type of employee
     */
    void changedType(int);
    /**
     * @brief fireEveryone To fire all the employees
     */
    void fireEveryone();
    /**
     * @brief fireSelected To fire only the selected employees
     */
    void fireSelected();
    /**
     * @brief createEmployee To create a new employee locally
     */
    void createEmployee();
    /**
     * @brief employeeHasBeenAdded To run when an employee has been added
     */
    void employeeHasBeenAdded(Employee*);
    /**
     * @brief employeeHasBeenDeleted To run when an employee has been deleted
     */
    void employeeHasBeenDeleted(Employee*);

private:
    // Local functions
    /**
     * @brief setup To setup the GUI
     */
    void setup();
    /**
     * @brief setMenu To prepare the top menu of the GUI
     */
    void setMenu();
    /**
     * @brief setUI To prepare the content of the GUI
     */
    void setUI();
    /**
     * @brief loadEmployees To load the employees of the company into the QListWidget
     */
    void loadEmployees();
    /**
     * @brief filterHide Function to return whether or not the given employee has to be hidden
     * @param employee The employee
     */
    bool filterHide(Employee* employee);

    // Local attributes
    /**
     * @brief company_ To store the company on which the GUI works
     */
    Company* company_;
    /**
     * @brief added_ To store the list of locally created employees
     */
    vector<Employee*> added_;
    /**
     * @brief companyIsLocal_ To store whether or not we're working on a company that has been
     * passed to us as a pointer or if we created one locally
     */
    bool companyIsLocal_;
    /**
     * @brief currentFilterIndex_ To store what is the current filter to apply to the employees list
     */
    int currentFilterIndex_;

    // Local attributes of QObjects
    /**
     * @brief employeesList Graphical list of the employees
     */
    QListWidget* employeesList;
    /**
     * @brief nameEditor Graphical edit field for the employee name
     */
    QLineEdit* nameEditor;
    /**
     * @brief nameEditor Graphical edit field for the employee salary
     */
    QLineEdit* salaryEditor;
    /**
     * @brief nameEditor Graphical edit field for the employee bonus
     */
    QLineEdit* bonusEditor;
    /**
     * @brief nameEditor List of radio buttons for the employee type
     */
    list<QRadioButton*> employeeTypeRadioButtons;
    /**
     * @brief fireButton Graphical button to fire an employee
     */
    QPushButton* fireButton;
    /**
     * @brief hireButton Graphical button to hire a new employee
     */
    QPushButton* hireButton;
};

#endif // MAINGUI_H
